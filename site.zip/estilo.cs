*{margin:0;}
body{font-family:sans-serif;}